#include <stdio.h>

main(){
	int i,sum = 0;
	while(i<1000){
		if(i%3==0 || i%5==0){
			sum+=i;
		}
		i++;
	}
	printf("The Sum of all numbers below 1000 that are multiples of 3 or 5 is: %d\n",sum);
}
