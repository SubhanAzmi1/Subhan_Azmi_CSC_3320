#!/bin/bash
./string2knuts.sh | ./sumoflist.sh
