#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    FILE *inputfp;
    FILE *outputfp;
    char c,p;
    int key;
    
    inputfp = fopen(argv[2],"r");
    
    if (argc != 4){
        printf("Incorrect number of arguments.\n");
        printf("Please re-run the propgram with the following format:\n");
        printf("$ ./keycrypt [1-26] [inputFileName] [outputFileName]\n");
        printf("For e.g.: $ ./keycrypt 2 message1.txt myOutputFile\n");
        return 0;
    }
    key = atoi(argv[1]);
    if (key<1 || key>26){
        printf("Incorrect key format.\n");
        printf("Please re-run the propgram with the following format:\n");
        printf("$ ./keycrypt [1-26] [inputFileName] [outputFileName]\n");
        printf("For e.g.: $ ./keycrypt 2 message1.txt myOutputFile\n");
        return 0;
    }
    
    if(inputfp==NULL){
        printf("Input file does not exist and/or does not have read+write permissions.\n");
        printf("Please re-run the propgram with the following format:\n");
        printf("$ ./keycrypt [1-26] [inputFileName] [outputFileName]\n");
        printf("For e.g.: $ ./keycrypt 2 message1.txt myOutputFile\n");
        return 0;
    }
    else{
        outputfp = fopen(argv[3],"w");
        printf("Key value entered: %d\n",key);
        while ((c = fgetc(inputfp)) != EOF) {

            //do something with each character, c.
            //lower first
            if(c >= 'A' && c <= 'Z')
            {
              	//lower
              	c = c + 32;
            }
            if(c >= 'a' && c <= 'z')
            {
              	//modulate with key
              	c = (c - 97 + key)%26 + 97;
            }
	    fputc(c,outputfp);
        }
    }
    fclose(inputfp);
    fclose(outputfp);
    return 0;
}


