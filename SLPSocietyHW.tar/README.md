My Submission to the SLP Society Assignment

Steps Taken:
1) Create "Submissions" folder in my /home/sazmi1 directory using "mkdir" 

2) Access /home/cumoja1/3320

3) Copy The Hunger Games.txt to my Submissions folder using "cp The\ Hunger\ Games.txt /home/sazmi1/Submissions"

4) Return to my Submissions folder and rename "The Hunger Games.txt" to "My Hunger Games" using "mv The\ Hunger\ Games.txt My\ Hunger\ Games.txt

5) After opening the document I searched for "Peeta" using ":/Peeta" to confirm the character name.

6) I then used ":%s/Peeta/Subhan/g" to replace all instances of "Peeta" with my name "Subhan" in the file.

From here the steps only describe what I would do to change access permissions as I do not have permission to do so.

7) At this point I would use "groups" with users "cumoja1" and "umahmood1", e.g: "groups cumoja1" to determine a group which these two users had in common but any other student was not part of.

8) After determining said group such as "eg-aff-faculty@gsuad.gsu.edu" I would change the group of the "Submissions" to said group with the command "chgrp -R eg-aff-faculty@gsuad.gsu.edu Submissions".

9) Lastly I would use "chmod" to remove "others" permission with the following command "chmod -R o-rwx Submissions". 

10) I could have also used "chown" to change ownership to another user as well using the following command "chown -R cumoja1 Submissions".
