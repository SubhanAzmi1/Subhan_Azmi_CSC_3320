def checkIfLeap(year):
  if year%400==0:
      return 3
  if year%4==0 and year%100!=0:
      return 3
  else:
      return 2
      
      
userInput = raw_input("Please type a year to check if it is a leap year: \n")
print("You typed: " + userInput + " as a: ")
print(type(userInput))
try:
  myInt = int(userInput)
  print("Converted to an integer: ")
  print(myInt)
  print(type(myInt))
  leapCheck = checkIfLeap(myInt)
  if leapCheck==3:
    print(userInput + " is a leap year.\n")
  else:
    print(userInput + " is NOT a leap year.\n")
except Exception as e:
  #print(str(e)) 
  print("Please rerun the program and enter only a number.")


