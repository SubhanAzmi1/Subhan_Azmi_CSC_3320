#include <stdio.h>

main(){
	int product=0;
	int largestProduct=0;
	int i,j;
	for (i=99; i>=10;i--){
                for(j=i; j>=10; j--){
                        product = i*j;
                        if(product<largestProduct){
                                break;
                        }
                        if(isPalindrome(product)==1){
                                largestProduct=product;
                                printf("Found a palindrome at: i = %d, j = %d, which is %d\n",i,j,largestProduct);
                        }
                }
        }
        printf("The largest palindrome made by the product of two 2-digit numbers is: %d\n", largestProduct);

	largestProduct=0;
	for (i=99; i>=10;i--){
                for(j=999; j>=100; j--){
                        product = i*j;
                        if(product<largestProduct){
                                break;
                        }
                        if(isPalindrome(product)==1){
                                largestProduct=product;
				printf("Found a palindrome at: i = %d, j = %d, which is %d\n",i,j,largestProduct);
                        }
                }
        }
        printf("The largest palindrome made by the product of a 2-digit and a 3 digit number is: %d\n", largestProduct);

	largestProduct=0;
	for (i=999; i>=100;i--){
		for(j=i; j>=100; j--){
			product = i*j;
			if(product<largestProduct){
				break;
			}
			if(isPalindrome(product)==1){
				largestProduct=product;
                                printf("Found a palindrome at: i = %d, j = %d, which is %d\n",i,j,largestProduct);
			}	
		}
	}
	printf("The largest palindrome made by the product of two 3-digit numbers is: %d\n", largestProduct);
}
int isPalindrome(int number){
	int reverse=0;
	int numberCopy=number;
	while (number !=0){
		reverse = reverse*10+(number%10);
		number = number / 10;
	}

	if(numberCopy == reverse){
		return 1;
	}
	return 0;
}
