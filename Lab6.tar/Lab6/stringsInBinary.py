# #stringsInBinary.py
from os import system
import os.path
from os import path
def main():
  x=1
  while x==1:
      print("Please enter fileName of a binary file to search and print strings.\nType 'Continue' to restart and 'End' at any point to exit.")
      inputFileInput = raw_input("Input FileName: ")
      if inputFileInput=='End':
        break
      if inputFileInput=='Continue':
        continue
      try:
        stringList=""
        if path.exists(inputFileInput)!=True:
          print("Please enter an input filename that exists within directory.")
          continue
        else:
          inputFile = open(inputFileInput,'rb')
          readByte = inputFile.read(1)
          while readByte !="":
            if ord(readByte)>31 and ord(readByte)<127:
              stringList+=readByte
            else: #if ord(readByte)==0:
              if len(stringList)!=0:
                print(stringList)
                stringList=""
            readByte = inputFile.read(1)
          #separator=""
          #print(separator.join(stringList))
          inputFile.close()
      except Exception as e:
        print(str(e)) 
        print("Please enter input fileName correctly.\nType 'Continue' to restart and 'End' at any point to exit.")
        continue

main()

