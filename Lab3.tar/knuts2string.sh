#!/bin/bash
awk '
BEGIN{
sign="";
galleons=sickles=knuts=remainder=0;
bracket="/";
reconvertedString=""}

{if (substr($0,1,1)=="-")
	{
	 sign="-";
	 gsub("-","",$0);
	 galleons=int($0/(23*17));
	 remainder=$0%(23*17);
	 sickles=int(remainder/17);
	 knuts=remainder%17;
	 reconvertedString=sign galleons bracket sickles bracket knuts}
else{
	 galleons=int($0/(23*17));
         remainder=$0%(23*17);
         sickles=int(remainder/17);
         knuts=remainder%17;
         reconvertedString=galleons bracket sickles bracket knuts}
print reconvertedString}'
