def main():
  print("Please type a number under 100 to convert to words:\nType 'EP' to exit.")
  x=1
  while x==1:
    userInput = raw_input()
    if len(userInput)>2:
      print("Please only type numbers under 100 in a 2-digit format to convert to words:\nType 'EP' to exit.")
      continue
    if userInput=='EP':
      break
    print("You typed: '" + userInput + "' as a: ")
    print(type(userInput))
    try:
      myInt = int(userInput)
      remainder = int(myInt%10)
      quotient = int(myInt/10)
      if quotient==0:
        print("You typed "+singleDigitToWord(remainder)+" as a number.\n")
        print("Please type a number under 100 to convert to words:\nType 'EP' to exit.")
      if quotient==1:
        print("You typed "+teens(remainder)+" as a number.\n")
        print("Please type a number under 100 to convert to words:\nType 'EP' to exit.")
      if quotient>1 and remainder ==0:
        print("You typed "+tys(quotient)+" as a number.\n")
        print("Please type a number under 100 to convert to words:\nType 'EP' to exit.")
      if quotient>1 and remainder >0:
        print("You typed "+tys(quotient)+" "+singleDigitToWord(remainder)+" as a number.\n")
        print("Please type a number under 100 to convert to words:\nType 'EP' to exit.")
      #print("Converted to an integer: ")
      #print(myInt)
      #print(type(myInt))
    except Exception as e:
      #print(str(e)) 
      print("Please only type numbers under 100 in a 2-digit format to convert to words:\nType 'EP' to exit.")
      continue
def singleDigitToWord(number):
  word = None
  if number==0:
    word ='Zero'
  if(number==1):
    word ='One'
  if(number==2):
    word ='Two'
  if(number==3):
    word ='Three'
  if(number==4):
    word ='Four'
  if(number==5):
    word ='Five'
  if(number==6):
    word ='Sox'
  if(number==7):
    word ='Seven'
  if(number==8):
    word ='Eight'
  if(number==9):
    word ='Nine'
  return word

def teens(number):
  word = None
  if(number==0):
    word ='Ten'
  if(number==1):
    word = 'Eleven'
  if(number==2):
    word = 'Twelve'
  if(number==3):
    word = 'Thirteen'
  if(number==4):
    word = 'Fourteen'
  if(number==5):
    word = 'Fifteen'
  if(number==6):
    word = 'Sixteen'
  if(number==7):
    word = 'Seventeen'
  if(number==8):
    word = 'Eighteen'
  if(number==9):
    word = 'Nineteen'
  return word

def tys(number):
  word = None
  if (number==2):
    word = "Twenty"
  if (number==3):
    word = "Thirty"
  if (number==4):
    word = "Forty"
  if (number==5):
    word = "Fifty"
  if (number==6):
    word = "Sixty"
  if (number==7):
    word = "Seventy"
  if (number==8):
    word = "Eighty"
  if (number==9):
    word = "Ninety"
  return word
main()
