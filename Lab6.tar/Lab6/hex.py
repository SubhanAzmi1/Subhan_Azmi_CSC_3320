#hex.py
from os import system
import os.path
from os import path
def main():
  x=1
  while x==1:
      print("Please enter input fileName to convert to an ASCII hex dump. Also enter an output fileName to be target of said hex dump\nType 'Continue' to restart and 'End' at any point to exit.")
      inputFileInput = raw_input("Input FileName: ")
      if inputFileInput=='End':
        break
      if inputFileInput=='Continue':
        continue
      print("Note: If output file exists it will be erased and written over.")
      outputFileInput = raw_input("Output FileName: ")
      if outputFileInput=='End':
        break
      if outputFileInput=='Continue':
        continue
      try:
        if path.exists(inputFileInput)!=True:
          print("Please enter an input filename that exists within directory.")
          continue
        else:
          inputFile = open(inputFileInput,'rb')
          outputFile = open(outputFileInput,'wb')
          readByte = inputFile.read(1)
          while readByte !="":
              outputFile.write(hex(ord(readByte)))
              readByte = inputFile.read(1)
          print("Hex dump text written to '"+outputFileInput+"'.\n")
          inputFile.close()  
          outputFile.close() 
      except Exception as e:
        print(str(e)) 
        print("Please enter input fileName correctly.\nType 'Continue' to restart and 'End' at any point to exit.")
        continue

main()

