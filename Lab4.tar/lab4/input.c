#include <stdio.h>

main(){
	char *line[100];
	printf("Please type something: \n");
	scanf(" %[^\n]",&line);
	printf("\nYou entered: %s\n", line);
}
