#include <stdio.h>
#include <string.h>
char * singleDigitToWord(int asciiValue1){
    char *word;
    if(asciiValue1==48)
        word = "Zero";
    if(asciiValue1==49)
        word = "One";
    if(asciiValue1==50)
        word = "Two";
    if(asciiValue1==51)
        word = "Three";
    if(asciiValue1==52)
        word = "Four";
    if(asciiValue1==53)
        word = "Five";
    if(asciiValue1==54)
        word = "Six";
    if(asciiValue1==55)
        word = "Seven";
    if(asciiValue1==56)
        word = "Eight";
    if(asciiValue1==57)
        word = "Nine";
    return (char *)word;
}
char * teens(int asciiValue2){
    char *word;
    if(asciiValue2==48)
        word = "Ten";
    if(asciiValue2==49)
        word = "Eleven";
    if(asciiValue2==50)
        word = "Twelve";
    if(asciiValue2==51)
        word = "Thirteen";
    if(asciiValue2==52)
        word = "Fourteen";
    if(asciiValue2==53)
        word = "Fifteen";
    if(asciiValue2==54)
        word = "Sixteen";
    if(asciiValue2==55)
        word = "Seventeen";
    if(asciiValue2==56)
        word = "Eighteen";
    if(asciiValue2==57)
        word = "Nineteen";
    return (char *)word;
}
char * tys(int asciiValue1){
    char *word;
    if(asciiValue1==50)
        word = "Twenty";
    if(asciiValue1==51)
        word = "Thirty";
    if(asciiValue1==52)
        word = "Forty";
    if(asciiValue1==53)
        word = "Fifty";
    if(asciiValue1==54)
        word = "Sixty";
    if(asciiValue1==55)
        word = "Seventy";
    if(asciiValue1==56)
        word = "Eighty";
    if(asciiValue1==57)
        word = "Ninety";
    return (char *)word;

}

int main(){
        char input[3];
        printf("Please type a number under 100 to convert to words:\nType 'EP' to exit.\n");
    
        while(1==1){
            scanf(" %[^\n]",input);
            if(strlen(input)>2){
                printf("Please only type numbers under 100 in a 2-digit format to convert to words:\nType 'EP' to exit.\n");
                continue;
            }
            if(strcmp(input,"EP")==0)
                break;
            int a,b,c;
            a = input[0]; //ascii
            b = input[1]; //ascii
            if(a==48 && (b>47 && b<58)){ // a=0 b=0-9
                printf("You typed %s (as an integer)\nType 'EP' to exit.\n", singleDigitToWord(b));
            }
            else if(b==0 && (a>47 && a<58)){ //  b=null a=0-9
                printf("You typed %s (as an integer)\nType 'EP' to exit.\n", singleDigitToWord(a));
            }
            else if(a==49 && (b>47 && b<58)){ //a =1 b=0-9
                printf("You typed %s (as an integer)\nType 'EP' to exit.\n", teens(b));
            }
            else if((a>49 && a<58) && (b>47 && b<58)){ //a=2-9 b=0-9
                if(b==48){
                    printf("You typed %s (as an integer)\nType 'EP' to exit.\n", tys(a));
                }
                else{
                    printf("You typed %s-%s (as an integer)\nType 'EP' to exit.\n",tys(a),singleDigitToWord(b));
                }
            }
            else{
                printf("You typed %s (as a string)\nPlease only type numbers under 100 in a 2-digit format to convert to words:\nType 'EP' to exit.\n", input);
            }
        }
        return 0;
}

