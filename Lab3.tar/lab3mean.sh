#!/bin/bash
awk '
BEGIN{
lineCounter=totalX=totalY=totalZ=meanX=meanY=meanZ=0}

{if($1=="HETATM")
	{lineCounter+=1;
	 totalX+=$7;
	 totalY+=$8;
	 totalZ+=$9
	}
}
END{	meanX=totalX/lineCounter; 
	meanY=totalY/lineCounter;
	meanZ=totalZ/lineCounter; 
	print "meanX = " meanX ", meanY= " meanY ", meanZ= " meanZ}'
