#binaryCommandsTest.py
from os import system
print("opening 'sumbelow1000' in read binary mode")
binaryInputFile = open("sumBelow1000","rb")
print("reading the opened file and assigning the data to an array")
binaryText = binaryInputFile.read()

print("opening 'sumCopied' in write binary mode")
outputFile = open("sumCopied","wb")

print("writing the previously read array into 'sumcopied'")
outputFile.write(binaryText)

print("closing files")
outputFile.close()
binaryInputFile.close()

print("changing permissions of old and new file")
system("chmod 777 sumBelow1000")
system("chmod 777 sumCopied")

print("running sumBelow1000:")
system("./sumBelow1000")

print("running the copied sumCopied:")
system("./sumCopied")

