LAB 4 – Simple Task in C

Steps to run programs:

1)Compile input.c using "gcc input.c -o input".
	1a)Type "./input" to run program.
	1b)Type your string and the program will print it back out.

2)Compile inputInt.c using "gcc inputInt.c -o inputInt".
	2a)Type "./inputInt" to run program.
	2b)Type your number in number format, not words, and the program will print it back out as an integer.

3)Compile leapYearCalc.c using "gcc leapYearCalc.c -o leapYearCalc".
	3a)Type "./leapYearCalc" to run program.
	3b)Type in a year in number format for the program to check if said year is a leap year.
		It will print out the result.
		If you type in a string it will not perform calculations and will alert you to rerun program.

4)Compile sumBelow1000.c using "gcc sumBelow1000.c -o sumBelow1000".
	4a)Type "./sumBelow1000" to run program. The program wil print result of sum of all numbers below 1000 divisible by 3 or 5

5)Compile palindrome.c using "gcc palindrome.c -o palindrome:.
	5a)Type "./palindrome" to run program. The program will print result of product of 2 and 3 digit numbers.

6)Compile say.c using "gcc say.c -o say".
	6a)Type "./say" to run program.
	6b)Follow printed instructions. Type numebrs in number format only such as "43".

7)Compile unsay.c using "gcc unsay.c -o unsay".
	7a)Type "./unsay" to run program.
	7b)Follow printed instructions. Type words correctly in the following format: "thirty-three or Thirteen."

8)Compile multiplyByWords.c using "gcc mulitplyByWords.c -o multiplyByWords".
	8a)Type "./multiplyByWords" to run program.
	8b)Follow printed instructions. Type words correctly in the following format: "Thirty three" to receive their product as output.
