/******************************************************************************
e, t, a, r, i , o , n , s , h , d, l , u , w, m, f, c, g,y, p , b , k , v , j ,x, q, z
*************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void updateArray(int letters[], char c){
    int i;
    for (i=0;i<26;i++){
        if (c==(97+i)){
            letters[i]+=1;
        }
    }
}
int mostLetter(int letters[]){
    int maxAlphabet = -1;
    int maxAlphabetPosition = -1;
    int i;
    for (i=0;i<26;i++){
        if(letters[i]>maxAlphabet){
            maxAlphabet=letters[i];
            maxAlphabetPosition = i;
        }
    }
    return maxAlphabetPosition;
}

int main(int argc, char *argv[])
{
    FILE *inputfp;
    char c,p;
    int i,key;
    int shift=0;
    int maxLetter=-1;
    int lettersCount[26]; // e is letters[4]
    for (i=0;i<26;i++){
        lettersCount[i]=0;
    }
    int eIsMaxAtKey[26];
    for (i=0;i<26;i++){
        eIsMaxAtKey[i]=0;
    }
    inputfp = fopen(argv[1],"r");
    
    if (argc != 2){
        printf("Incorrect number of arguments.\n");
        printf("Please re-run the propgram with the following format:\n");
        printf("$ ./findfilekey [inputFileName]\n");
        printf("For e.g.: $ ./findfilekey ceaser1.txt\n");
        return 0;
    }
    
    if(inputfp==NULL){
        printf("Input file does not exist and/or does not have read+write permissions.\n");
        printf("Please re-run the propgram with the following format:\n");
        printf("$ ./findfilekey [inputFileName]\n");
        printf("For e.g.: $ ./findfilekey ceaser1.txt\n");
        return 0;
    }
    else{
        while(shift!=26){
            
            while ((c = fgetc(inputfp)) != EOF) {
    
                //do something with each character, c.
                //lower first
                if(c >= 'A' && c <= 'Z')
                {
                  	c = c + 32;
                }
                if(c >= 'a' && c <= 'z')
                {
                  	//modulate with key
                  	c = (c - 97 + shift)%26 + 97;
                  	//add to letters count
                  	updateArray(lettersCount,c);
                  	 
                }
            }
            //check which was the most letters
            maxLetter=mostLetter(lettersCount);
            printf("most occurences of letter at alphabet position: %d with shift: %d\n",maxLetter+1,shift);
            //if e is the most then uptick key
            if(maxLetter==4){
                eIsMaxAtKey[shift]+=1;
            }
            //reset lettercount
            for (i=0;i<26;i++){
                lettersCount[i]=0;
            } 
            //inc shift
            shift++;
            //reset file pointer to begin of file
            fseek(inputfp,0,SEEK_SET);
        }
        //which shifts had e as the most occurences
        for(i=0;i<26;i++){
            if(eIsMaxAtKey[i]==1){
                printf("Letter 'e' had most occurences with shift: %d\n",i);
            }
        }
    }
    fclose(inputfp);
    return 0;
}


