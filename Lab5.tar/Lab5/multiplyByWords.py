def main():
  print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.\nType 'End' to exit.")
  x=1
  int1=None
  int2=None
  int3=None
  while x==1:
    firstInput = raw_input("Frist number: ")
    if firstInput=='End':
      break
    secondInput = raw_input("Second number: ")
    if secondInput=='End':
      break
    try:
      if stringToNum(firstInput)!=100:
        int1=stringToNum(firstInput)
      else:
        print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.")
        continue
      if stringToNum(secondInput)!=100:
        int2=stringToNum(secondInput)
      else:
        print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.")
        continue
      int3=int1*int2
      int1String=str(int1)
      int2String=str(int2)
      int3String=str(int3)
      print("The product of "+int1String+" and "+int2String+" is: "+int3String)
      print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.\nType 'End' to exit.")
    except Exception as e:
      print(str(e)) 
      print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.\nType 'End' to exit.")
      continue

def stringToNum(wordInput):
  int1=None
  int2=None
  number=100 #above values
  try:
      wordInput = wordInput.lower()
      inputList = wordInput.split("-")
      listLength = len(inputList)
      if listLength<2:
        if singleWordToDigit(inputList[0])!=21:
          int1 = singleWordToDigit(inputList[0])
          number=int1
          return number
        elif teens(inputList[0])!=21:
          int1 = teens(inputList[0])
          number=int1
          return number
        elif tys(inputList[0])!=21:
          int1 = tys(inputList[0])
          number=int1
          return number
        else:
          return number
      elif listLength==2:
        if tys(inputList[0])!=21:
          int1 = tys(inputList[0])
        else:
          return number
        if singleWordToDigit(inputList[1])>0 and singleWordToDigit(inputList[1])<21:
          int2 = singleWordToDigit(inputList[1])
          number=int1+int2
          return number
        else:
          return number
      else:
        return number
  except Exception as e:
      print(str(e)) 
      print("Please type two numbers under 100 with format similar to:\nThirty-Three\nEleven\nto output their product.\nType 'End' to exit.")

def singleWordToDigit(word):
  number=21
  if word =="zero":
    number=0
  if word =="one":
    number=1
  if word =="two":
    number=2
  if word =="three":
    number=3
  if word =="four":
    number=4
  if word =="five":
    number=5
  if word =="six":
    number=6
  if word =="seven":
    number=7
  if word =="eight":
    number=8
  if word =="nine":
    number=9
  return number

def teens(word):
  number=21
  if word=="ten":
    number=10
  if word=="eleven":
    number=11
  if word=="twelve":
    number=12
  if word=="thirteen":
    number=13
  if word=="fourteen":
    number=14
  if word=="fifteen":
    number=15
  if word=="sixteen":
    number=16
  if word=="seventeen":
    number=17
  if word=="eighteen":
    number=18
  if word=="nineteen":
    number=19
  return number

def tys(word):
  number=21
  if word=="twenty":
    number=20
  if word=="thirty":
    number=30
  if word=="forty":
    number=40
  if word=="fifty":
    number=50
  if word=="sixty":
    number=60
  if word=="seventy":
    number=70
  if word=="eighty":
    number=80
  if word=="ninety":
    number=90
  return number

main()
