def main():
  product=0
  largestProduct=0
  for  i in range (99,9,-1):
    for j in range (i,9,-1):
      product=i*j
      if product<largestProduct:
        break
      if isPalindrome(product)==1:
        largestProduct=product
        iString = str(i)
        jString = str(j)
        largestProductString = str(largestProduct)
        print("Found a palindrome at: i = " + iString + ", j = " + jString + ", which is " + largestProductString)
  print("The largest palindrome made by the product of two 2-digit numbers is: "+largestProductString+"\n")  

  largestProduct=0
  for  i in range (99,9,-1):
    for j in range (999,99,-1):
      product=i*j
      if product<largestProduct:
        break
      if isPalindrome(product)==1:
        largestProduct=product
        iString = str(i)
        jString = str(j)
        largestProductString = str(largestProduct)
        print("Found a palindrome at: i = " + iString + ", j = " + jString + ", which is " + largestProductString)
  print("The largest palindrome made by the product of a 2-digit and a 3 digit number is: "+largestProductString+"\n")  

  largestProduct=0
  for  i in range (999,99,-1):
    for j in range (i,99,-1):
      product=i*j
      if product<largestProduct:
        break
      if isPalindrome(product)==1:
        largestProduct=product
        iString = str(i)
        jString = str(j)
        largestProductString = str(largestProduct)
        print("Found a palindrome at: i = " + iString + ", j = " + jString + ", which is " + largestProductString)
  print("The largest palindrome made by the product of two 3-digit numbers is: "+largestProductString+"\n")   

def isPalindrome(number):
  reverse=0
  numberCopy=number

  while number!=0:
    reverse = reverse*10 + (number%10)
    number = number/10

  if numberCopy == reverse:
    return 1
  return 0

main()
