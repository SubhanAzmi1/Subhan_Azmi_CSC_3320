#!/bin/bash
awk '
BEGIN{
sign="";
galleons=sickles=knuts=totalKnutsPerLine=0}

{if(substr($1,1,1)=="-")
	{sign="-";
	 gsub("-","",$0);
	 split($0,splitString,"/");
	 galleons=splitString[1];
	 sickles=splitString[2];
	 knuts=splitString[3];
 	 totalKnutsPerLine=(((galleons*23)+sickles)*17)+knuts;
	 totalKnutsPerLine=-totalKnutsPerLine}
else{split($0,splitString,"/");
	 galleons=splitString[1];
         sickles=splitString[2];
         knuts=splitString[3];
         totalKnutsPerLine=(((galleons*23)+sickles)*17)+knuts}
print totalKnutsPerLine}'
