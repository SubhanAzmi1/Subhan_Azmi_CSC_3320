/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int singleWordToDigit(char word1[]){
    int number = 21;//arbitrary
    if(strcmp(word1,"zero")==0)
        number = 0;
    if(strcmp(word1,"one")==0)
        number = 1;
    if(strcmp(word1,"two")==0)
        number = 2;
    if(strcmp(word1,"three")==0)
        number = 3;
    if(strcmp(word1,"four")==0)
        number = 4;
    if(strcmp(word1,"five")==0)
        number = 5;
    if(strcmp(word1,"six")==0)
        number = 6;
    if(strcmp(word1,"seven")==0)
        number = 7;
    if(strcmp(word1,"eight")==0)
        number = 8;
    if(strcmp(word1,"nine")==0)
        number = 9;
    return number;
}
int teens(char word1[]){
    int number=21;//arbitrary
    if(strcmp(word1,"ten")==0)
        number = 10;
    if(strcmp(word1,"eleven")==0)
        number = 11;
    if(strcmp(word1,"twelve")==0)
        number = 12;
    if(strcmp(word1,"thirteen")==0)
        number = 13;
    if(strcmp(word1,"fourteen")==0)
        number = 14;
    if(strcmp(word1,"fifteen")==0)
        number = 15;
    if(strcmp(word1,"sixteen")==0)
        number = 16;
    if(strcmp(word1,"seventeen")==0)
        number = 17;
    if(strcmp(word1,"eighteen")==0)
        number = 18;
    if(strcmp(word1,"nineteen")==0)
        number = 19;
    return number;
}
int tys(char word1[]){
    int number=21;//arbitrary
    if(strcmp(word1,"twenty")==0)
        number = 20;
    if(strcmp(word1,"thirty")==0)
        number = 30;
    if(strcmp(word1,"forty")==0)
        number = 40;
    if(strcmp(word1,"fifty")==0)
        number = 50;
    if(strcmp(word1,"sixty")==0)
        number = 60;
    if(strcmp(word1,"seventy")==0)
        number = 70;
    if(strcmp(word1,"eighty")==0)
        number = 80;
    if(strcmp(word1,"ninety")==0)
        number = 90;
    return number;

}

int main(){
        char input[20];
        char * token_space;
        char * token_space2;
        int i,int1,int2,int3;
        printf("Please type two numbers under 100 with format 'Thirty Three' or 'thirteen twelve' to output their product:\nType 'End' to exit.\n");
    
        while(1==1){
            scanf(" %[^\n]",input);
            
            if(strcmp(input,"End")==0)
                break;
            
            //lower the input
            for (i = 0; input[i]; i++)
          	{
          		if(input[i] >= 'A' && input[i] <= 'Z')
          		{
          			input[i] = input[i] + 32;
        		}
          	}
            //split it
            token_space = strtok(input," "); //split on " "
            token_space2 = strtok(NULL," ");
            
            // only 1 word cant mulitply
            if(token_space2==NULL){
                // only 1 word cant mulitply
                printf("Please type in numbers correctly following the format: 'Thirty Three' or 'thirteen twelve.'\n");
                printf("You may only use one word numbers. please do not use for e.g.: twenty-one\n");
                continue;
            }
            else{
                //convert first word
                if(singleWordToDigit(token_space)!=21){//no real single word result is currently 21
                    int1 = singleWordToDigit(token_space);
                }
                else if(teens(token_space)!=21){//no real single word result is currently 21
                    int1 = teens(token_space);
                }
                else if(tys(token_space)!=21){//no real single word result is currently 21
                    int1 = tys(token_space);
                }
                else{
                    printf("Please type in numbers correctly following the format: 'Thirty Three' or 'thirteen twelve.'\n");
                    printf("You may only use one word numbers. please do not use for e.g.: twenty-one\n");
                    continue;
                }
                //what is the second word
                if(singleWordToDigit(token_space2)!=21){//no real single word result is currently 21
                    int2=singleWordToDigit(token_space2);
                    int3=int1*int2;
                    printf("You typed %d and %d as words\n", int1,int2);
                    printf("The product of %d and %d is: %d\nType 'End' to exit.\n",int1,int2,int3);
                }
                else if(teens(token_space2)!=21){//no real single word result is currently 21
                    int2=teens(token_space2);
                    int3=int1*int2;
                    printf("You typed %d and %d as words\n", int1,int2);
                    printf("The product of %d and %d is: %d\nType 'End' to exit.\n",int1,int2,int3);
                }
                else if(tys(token_space2)!=21){//no real single word result is currently 21
                    int2=tys(token_space2);
                    int3=int1*int2;
                    printf("You typed %d and %d as words\n", int1,int2);
                    printf("The product of %d and %d is: %d\nType 'End' to exit.\n",int1,int2,int3);
                }
                else{
                    printf("Please type in numbers correctly following the format: 'Thirty Three' or 'thirteen twelve.'\n");
                    printf("You may only use one word numbers. please do not use for e.g.: twenty-one\n");
                }
            }
            
        }
        return 0;
}

