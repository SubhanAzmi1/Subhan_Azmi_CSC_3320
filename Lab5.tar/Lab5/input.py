import sys
userInput = raw_input("Please enter something: \n")
print("You typed: " + userInput)
