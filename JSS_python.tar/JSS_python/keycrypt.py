import fileinput
import os.path
from os import path

def main():
  print("Please enter key value, input fileName, and output filename.\nType 'Continue' to restart. Type 'End' at any point to exit.")
  x=1
  wasCapital=False
  while x==1:
    keyInput = raw_input("Key Value [1-26]: ")
    if keyInput=='End':
      break
    if keyInput=='Continue':
      continue
    inputFileInput = raw_input("Input FileName: ")
    if inputFileInput=='End':
      break
    if inputFileInput=='Continue':
      continue
    print("Note: If output file exists it will be erased and written over.")
    outputFileInput = raw_input("Output FileName: ")
    if outputFileInput=='End':
      break
    if outputFileInput=='Continue':
      continue
    try:
      key = int(keyInput)
      if key<1 or key>26:
        print("Please enter key value between 1-26.\nType 'End' at any point to exit.")
        continue
      if path.exists(inputFileInput)!=True:
        print("Please enter an input filename that exists.\nType 'End' at any point to exit.")
        continue
      else:
        outputFile = open(outputFileInput,'w')
        inputFile = open(inputFileInput,'r')
        for line in inputFile:
          for c in line:
            #lower first
            if c>='A' and c<='Z':
              c = c.lower()
              wasCapital=True
            if c>='a' and c<='z':
              #modulate with key
              c = chr((ord(c)-97+key)%26+97)
            if wasCapital==True:
              c = c.upper()
            wasCapital=False
            outputFile.write(c)
        inputFile.close()    
        outputFile.close() 
    except Exception as e:
      print(str(e)) 
      print("Please enter key value, input fileName, and output filename correctly.\nType 'End' at any point to exit.")
      continue

main()

