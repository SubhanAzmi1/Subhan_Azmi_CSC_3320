#include <stdio.h>

int main(){
	char *inputInt[200];
	printf("Please type an integer \n");
	scanf(" %[^\n]",&inputInt);
	int a;
	a=atoi(&inputInt);
	if(a==0){
		printf("You entered: %s (as a string)\n", &inputInt);
		return 0;
	}
	printf("You entered: %d (as an integer)\n", a);
	return 0;
}
