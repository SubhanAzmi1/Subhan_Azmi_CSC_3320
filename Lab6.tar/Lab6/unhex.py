#unhex.py
from os import system
import os.path
from os import path
def main():
  x=1
  while x==1:
      print("Please enter input fileName to revert from an ASCII hex dump. Also enter an output fileName to be target of said unHex.\nType 'Continue' to restart and 'End' at any point to exit.")
      inputFileInput = raw_input("Input FileName: ")
      if inputFileInput=='End':
        break
      if inputFileInput=='Continue':
        continue
      print("Note: If output file exists it will be erased and written over.")
      outputFileInput = raw_input("Output FileName: ")
      if outputFileInput=='End':
        break
      if outputFileInput=='Continue':
        continue
      try:
        if path.exists(inputFileInput)!=True:
          print("Please enter an input filename that exists within directory.")
          continue
        else:
          inputFile = open(inputFileInput,'rb')
          outputFile = open(outputFileInput,'wb')
          readDATA = inputFile.read()
          inputList = readDATA.split("0x")
          inputList.pop(0)
          #print("Printing hex file")
          #for i in inputList:
          #  print(i),
          for i in inputList:
              char = chr(int(i,16))
              outputFile.write(char)
          print("\nHex dump text written to '"+outputFileInput+"'.\n")
          #print("printing unhexed file")
          #system("head -1 "+outputFileInput)
          inputFile.close()  
          outputFile.close() 
      except Exception as e:
        print(str(e)) 
        print("Please enter input fileName correctly.\nType 'Continue' to restart and 'End' at any point to exit.")
        continue

main()

