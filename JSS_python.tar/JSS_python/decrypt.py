import fileinput
import os.path
from os import path

def main():
  x=1
  key=None
  shift=0
  maxLetter=-1
  wasCapital=False
  eIsMaxAtKey=[]
  for i in range(0,26,1):
    eIsMaxAtKey.append(0)
  while x==1:
    print("Please enter input fileName and output fileName to find key and write decrypted text to output file.\nType 'Continue' to restart and 'End' at any point to exit.")
    inputFileInput = raw_input("Input FileName: ")
    if inputFileInput=='End':
      break
    if inputFileInput=='Continue':
      continue
    print("Note: If output file exists it will be erased and written over.")
    outputFileInput = raw_input("Output FileName: ")
    if outputFileInput=='End':
      break
    if outputFileInput=='Continue':
      continue
    try:
      if path.exists(inputFileInput)!=True:
        print("Please enter an input filename that exists within directory.")
        continue
      else:
        while shift!=26:
          inputFile = open(inputFileInput,'r')
          for line in inputFile:
            for c in line:
              #lower first
              if c>='A' and c<='Z':
                c = c.lower()
              if c>='a' and c<='z':
                #modulate with key
                c = chr((ord(c)-97+shift)%26+97)
                #add to letters count
                updateArray(c)
          #check which was the most letters
          maxLetter = mostLetter()
          #if e is the most then uptick key
          if maxLetter==4:
            eIsMaxAtKey[shift]+=1
          #reset lettercount
          for i in range(0,26,1):
            lettersCount[i]=0
          #inc shift
          shift+=1
          inputFile.close() 
        #which shifts had e as the most occurences  
        for i in range(0,26,1):
            if eIsMaxAtKey[i]==1:
              iString=str(i)
              print("Letter 'e' had most occurences with shift: "+iString)
              key=i
        inputFile = open(inputFileInput,'r')
        outputFile = open(outputFileInput,'w')
        for line in inputFile:
          for c in line:
            #lower first
            if c>='A' and c<='Z':
              c = c.lower()
              wasCapital=True
            if c>='a' and c<='z':
              #modulate with key
              c = chr((ord(c)-97+key)%26+97)
            if wasCapital==True:
              c = c.upper()
            wasCapital=False
            outputFile.write(c)
        print("Decrypted text written to '"+outputFileInput+"'.\n")
        inputFile.close()  
        outputFile.close()   
    except Exception as e:
      print(str(e)) 
      print("Please enter input fileName correctly.\nType 'Continue' to restart and 'End' at any point to exit.")
      continue

def updateArray(c):
  for i in range(0,26,1):
    if ord(c)==(97+i):
      lettersCount[i]+=1

def mostLetter():
  maxAlphabet=-1
  maxAlphabetPosiiton=-1
  for i in range(0,26,1):
    if lettersCount[i]>maxAlphabet:
      maxAlphabet=lettersCount[i]
      maxAlphabetPosition=i
  return maxAlphabetPosition

lettersCount=[] #e is letters[4]
for i in range(0,26,1):
  lettersCount.append(0)
main()
