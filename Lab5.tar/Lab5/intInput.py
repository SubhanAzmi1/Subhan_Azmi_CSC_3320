userInput = raw_input("Please enter an integer: \n")
print("You typed: " + userInput + " as a: ")
print(type(userInput))
try:
  myInt = int(userInput)
  print("Converted to an integer: ")
  print(myInt)
  print(type(myInt))
except:
  print("unable to convert input string into integer.")
