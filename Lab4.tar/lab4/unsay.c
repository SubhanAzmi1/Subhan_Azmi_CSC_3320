/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int singleWordToDigit(char word1[]){
    int number = 21;//arbitrary
    if(strcmp(word1,"zero")==0)
        number = 0;
    if(strcmp(word1,"one")==0)
        number = 1;
    if(strcmp(word1,"two")==0)
        number = 2;
    if(strcmp(word1,"three")==0)
        number = 3;
    if(strcmp(word1,"four")==0)
        number = 4;
    if(strcmp(word1,"five")==0)
        number = 5;
    if(strcmp(word1,"six")==0)
        number = 6;
    if(strcmp(word1,"seven")==0)
        number = 7;
    if(strcmp(word1,"eight")==0)
        number = 8;
    if(strcmp(word1,"nine")==0)
        number = 9;
    return number;
}
int teens(char word1[]){
    int number=21;//arbitrary
    if(strcmp(word1,"ten")==0)
        number = 10;
    if(strcmp(word1,"eleven")==0)
        number = 11;
    if(strcmp(word1,"twelve")==0)
        number = 12;
    if(strcmp(word1,"thirteen")==0)
        number = 13;
    if(strcmp(word1,"fourteen")==0)
        number = 14;
    if(strcmp(word1,"fifteen")==0)
        number = 15;
    if(strcmp(word1,"sixteen")==0)
        number = 16;
    if(strcmp(word1,"seventeen")==0)
        number = 17;
    if(strcmp(word1,"eighteen")==0)
        number = 18;
    if(strcmp(word1,"nineteen")==0)
        number = 19;
    return number;
}
int tys(char word1[]){
    int number=21;//arbitrary
    if(strcmp(word1,"twenty")==0)
        number = 20;
    if(strcmp(word1,"thirty")==0)
        number = 30;
    if(strcmp(word1,"forty")==0)
        number = 40;
    if(strcmp(word1,"fifty")==0)
        number = 50;
    if(strcmp(word1,"sixty")==0)
        number = 60;
    if(strcmp(word1,"seventy")==0)
        number = 70;
    if(strcmp(word1,"eighty")==0)
        number = 80;
    if(strcmp(word1,"ninety")==0)
        number = 90;
    return number;

}

int main(){
        char input[20];
        char * token;
        char * token2;
        int i,int1,int2;
        printf("Please type a number under 100 with format 'Thirty-Three or Thirty' to convert to integer:\nType 'End' to exit.\n");
    
        while(1==1){
            scanf(" %[^\n]",input);
            
            if(strcmp(input,"End")==0)
                break;
            
            //lower the input
            for (i = 0; input[i]; i++)
          	{
          		if(input[i] >= 'A' && input[i] <= 'Z')
          		{
          			input[i] = input[i] + 32;
        		}
          	}
            //split it
            token = strtok(input,"-"); //split on -
            token2 = strtok(NULL,"-");
            if(token2==NULL){
                // what is the first and only word
                if(singleWordToDigit(token)!=21){//no real single word result is 21
                    printf("You typed %d as a word\nType 'End' to exit.\n", singleWordToDigit(token));
                }
                else if(teens(token)!=21){//no real single word result is 21
                    printf("You typed %d as a word\nType 'End' to exit.\n", teens(token));
                }  
                else if(tys(token)!=21){//no real single word result is 21
                    printf("You typed %d as a word\nType 'End' to exit.\n", tys(token));
                }
                else{
                    printf("Please type in numbers correctly following the format: 'Thirty-Three or Thirty'\n");
                    continue;
                }
            }
            else{
                //convert first word
                if(tys(token)!=21){//no real single word result is 21
                    int1 = tys(token);
                }
                else{
                    printf("Please type in numbers correctly following the format: 'Thirty-Three or Thirty'\n");
                    continue;
                }
                //what is the second word
                if(singleWordToDigit(token2)!=21){//no real single word result is 21
                    int2=singleWordToDigit(token2);
                    int1+=int2;
                    printf("You typed %d as a word\nType 'End' to exit.\n", int1);
                }
                else{
                    printf("Please type in numbers correctly following the format: 'Thirty-Three or Thirty'\n");
                }
            }
            
        }
        return 0;
}

